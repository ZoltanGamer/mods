Downloaded from SkyMods:

http://hearts-of-iron-4.smods.ru
https://plus.google.com/u/0/communities/100644482381435508067

Hearts of Iron IV: Mods Catalogue

HOW TO INSTALL MODS

Unpack mod folder in
C:\Users\*Username*\Documents\Paradox Interactive\Hearts of Iron IV\workshop\content\281990\

Unpack .mod file in
C:\Users\*Username*\Documents\Paradox Interactive\Hearts of Iron IV\mod

Enable desired mods from the launcher, and click Play button.
Enjoy the game:)